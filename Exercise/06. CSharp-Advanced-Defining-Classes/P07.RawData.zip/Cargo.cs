﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P07.RawData
{
    public class Cargo
    {
        public Cargo(string type, int weigth)
        {
            this.Type = type;
            this.Weigth = weigth;
        }

        public string Type  { get; set; }

        public int Weigth { get; set; }
    }
}
