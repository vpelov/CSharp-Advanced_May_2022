﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P07.RawData
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Car> carsList = new List<Car>();

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string[] data = Console.ReadLine()
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();

                string model = data[0];
                int engineSpeed = int.Parse(data[1]);
                int enginePower = int.Parse(data[2]);
                int cargoWeight = int.Parse(data[3]);
                string cargoType = data[4];

                Engine engine = new Engine(engineSpeed, enginePower);
                Cargo cargo = new Cargo(cargoType, cargoWeight);

                Tires[] tireArr = new Tires[4];

                int counter = 0;
                for (int j = 5; j <= 12; j += 2)
                {
                    double pressure = double.Parse(data[j]);
                    int age = int.Parse(data[j + 1]);

                    Tires currentTire = new Tires(age, pressure);
                    tireArr[counter] = currentTire;
                    counter++;

                }

                Car car = new Car(model, engine, cargo, tireArr);
                carsList.Add(car);
            }

            string command = Console.ReadLine();
            List<Car> printList = new List<Car>();

            if (command == "fragile")
            {
                foreach (Car item in carsList)
                {
                    if (item.Cargo.Type == "fragile")
                    {
                        foreach (var tire in item.Tires)
                        {
                            if (tire.Pressure < 1)
                            {
                                printList.Add(item);
                                break;
                            }
                        }
                    }
                }

                //printList = carsList.Where(x => x.Cargo.Type == "fragile" && x.Tires.Any( p => p.Pressure < 1)).ToList();     // var.2
            }
            else if (command == "flammable")
            {
                foreach (Car item in carsList)
                {
                    if (item.Cargo.Type == "flammable")
                    {
                        if (item.Engine.Power > 250)
                        {
                            printList.Add(item);
                        }
                    }
                }


                //printList = carsList.Where(x => x.Cargo.Type == "flammable" && x.Engine.Power > 250).ToList();     // var.2
            }

            foreach (Car item in printList)
            {
                Console.WriteLine($"{item.Model}");
            }

        }
    }
}
