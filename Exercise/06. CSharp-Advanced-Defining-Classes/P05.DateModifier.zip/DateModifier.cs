﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P05.DateModifier
{
    internal class DateModifier
    {
        public static int GetDiff(string one, string two)
        {
            DateTime start = DateTime.Parse(one);
            DateTime end = DateTime.Parse(two);

            int diff = Math.Abs((start - end).Days);

                
            return diff;
        }

    }
}
