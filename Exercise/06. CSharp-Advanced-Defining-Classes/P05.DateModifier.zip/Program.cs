﻿using System;

namespace P05.DateModifier
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string firstDate = Console.ReadLine();
            string secondDate = Console.ReadLine();

            int n = P05.DateModifier.DateModifier.GetDiff(firstDate, secondDate);
            Console.WriteLine(n);
        }
    }
}
