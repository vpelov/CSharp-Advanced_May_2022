﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Family listWork = new Family();
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string[] current = Console.ReadLine()
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();
                if (int.Parse(current[1]) > 30)
                {
                    Person person = new Person(current[0], int.Parse(current[1]));
                    listWork.AddMember(person);
                }
            }

            List<Person> currentList = new List<Person>();
            currentList = listWork.PeopleList.OrderBy(x => x.Name).ToList();
           
            for (int i = 0; i < currentList.Count; i++)
            {
                Person current = currentList[i];
                string name = current.Name;
                int age = current.Age;

                Console.WriteLine($"{name} - {age}");
            }
        }
    }
}
