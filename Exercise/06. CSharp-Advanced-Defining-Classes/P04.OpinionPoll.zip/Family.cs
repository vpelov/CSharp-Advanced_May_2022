﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    public class Family
    {

        public List<Person> PeopleList { get; set; } = new List<Person>();


        public void AddMember(Person person)
        {
            PeopleList.Add(person);        
        }


        public void GetOldestMember()
        {
            int minAge = int.MinValue;
            string minAgeName = string.Empty;

            foreach (Person item in PeopleList)
            {
                int age = item.Age;
                string name = item.Name;
                if (age > minAge)
                {
                    minAge = age;
                    minAgeName = name;
                }
            }

            Console.WriteLine($"{minAgeName} {minAge}");           
        }
    }
}
