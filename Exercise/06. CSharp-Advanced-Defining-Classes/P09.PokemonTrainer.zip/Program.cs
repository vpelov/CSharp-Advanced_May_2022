﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P09.PokemonTrainer
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Trainers> trainersList = new List<Trainers>();

            string cmd = Console.ReadLine();
            while (cmd != "Tournament")
            {
                string[] command = cmd.Split(' ', StringSplitOptions.RemoveEmptyEntries).ToArray();
                string trainerName = command[0];
                string pokemonName = command[1];
                string pokemonElement = command[2];
                int health = int.Parse(command[3]);

                Pokemon pokemon = new Pokemon(pokemonName, pokemonElement, health);

                if (!trainersList.Any(x => x.Name == trainerName))
                {
                    Trainers trainer = new Trainers();
                    trainer.Name = trainerName;
                    trainer.NumberBadges = 0;
                    trainer.PokemonList.Add(pokemon);

                    trainersList.Add(trainer);
                }
                else
                {
                    Trainers currentTrainer = trainersList.First(x => x.Name == trainerName);
                    currentTrainer.PokemonList.Add(pokemon);
                }

                cmd = Console.ReadLine();
            }

            string data = Console.ReadLine();
            while (data != "End")
            {
                foreach (Trainers item in trainersList)
                {
                    if (item.PokemonList.Any(x => x.Element == data))
                    {
                        item.NumberBadges++;
                    }
                    else
                    {
                        foreach (var pokemon in item.PokemonList)
                        {
                            pokemon.Health -= 10;
                            if (pokemon.Health <= 0)
                            {
                                item.PokemonList.Remove(pokemon);
                                break;
                            }
                        }
                    }
                }
                data = Console.ReadLine();
            }

            List<Trainers> printList = trainersList.OrderByDescending(x => x.NumberBadges).ToList();

            foreach (Trainers item in printList)
            {
                Console.WriteLine($"{item.Name} {item.NumberBadges} {item.PokemonList.Count}");
            }

            //"{trainerName} {badges} {numberOfPokemon}"
        }
    }
}
