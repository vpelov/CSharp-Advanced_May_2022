﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftUniParking
{
    public class Parking
    {
        public Parking(int capacity)
        {
            this.capacity = capacity;
            carsList = new List<Car>();
        }

        public int capacity { get; set; }

        public List<Car> carsList { get; set; }

    }
}
