﻿using System;
using System.Linq;

namespace SoftUniParking
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string[] command = Console.ReadLine().Split(", ", StringSplitOptions.RemoveEmptyEntries).ToArray();

            string make = command[0];
            string model = command[1];
            int horsePower = int.Parse(command[2]);
            string regNumber = command[3];

            Car car = new Car(make, model, horsePower, regNumber);
            Console.WriteLine(car);
        }
    }
}
