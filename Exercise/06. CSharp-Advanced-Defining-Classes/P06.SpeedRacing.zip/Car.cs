﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace P06.SpeedRacing
{
    internal class Car
    {
        public Car(string model, double fuelAmount, double fuelPerKm)
        {
            this.Model = model;
            this.FuelAmount = fuelAmount;
            this.FuelConsumptionPerKilometer = fuelPerKm;
        }


        public string Model { get; set; }

        public double FuelAmount { get; set; }

        public double FuelConsumptionPerKilometer { get; set; }

        public double TravelledDistance = 0;


        public static void GetTravel(string model, double amountOfKilometers, List<Car> carList)
        {
            Car current = carList.First(x => x.Model == model);


            if (current.FuelAmount >= amountOfKilometers * current.FuelConsumptionPerKilometer)
            {
                current.FuelAmount -= amountOfKilometers * current.FuelConsumptionPerKilometer;
                current.TravelledDistance += amountOfKilometers;
            }
            else
            {
                Console.WriteLine("Insufficient fuel for the drive");                
            }        
        }
    }
}
