﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P06.SpeedRacing
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Car> carList = new List<Car>();
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string[] data = Console.ReadLine()
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();

                string model = data[0];
                double fuelAmount = double.Parse(data[1]);
                double fuelPerKilometers = double.Parse(data[2]);

                Car currentCar = new Car(model, fuelAmount, fuelPerKilometers);
                carList.Add(currentCar);
            }

            string cmd = Console.ReadLine();
            while (cmd != "End")
            {
                string[] command = cmd
                    .Split(' ',StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();
                string model = command[1];
                double amountOfKilometers = double.Parse(command[2]);

                P06.SpeedRacing.Car.GetTravel(model, amountOfKilometers, carList);

                cmd = Console.ReadLine();
            }

            foreach (Car car in carList)
            {
                Console.WriteLine($"{car.Model} {car.FuelAmount:f2} {car.TravelledDistance}");
            }
        }
    }
}
