﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P08.CarSalesan
{
    public class Engine
    {
        public string Model{ get; set; }

        public int Power { get; set; }

        public int? Dispalcement { get; set; }

        public string Efficincy { get; set; }
    }
}



