﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P08.CarSalesan
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Engine> engineList = new List<Engine>();
            List<Car> carList = new List<Car>();

            int numberEngine = int.Parse(Console.ReadLine());
            for (int i = 0; i < numberEngine; i++)
            {
                string[] data = Console.ReadLine()
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();
                string model = data[0];
                int power = int.Parse(data[1]);

                Engine engine = new Engine();
                engine.Model = model;
                engine.Power = power;

                if (data.Length == 4)
                {
                    int displacement = int.Parse(data[2]);
                    string efficiency = data[3];

                    engine.Dispalcement = displacement;
                    engine.Efficincy = efficiency;
                }
                else if (data.Length == 3)
                {
                    bool isNumber = int.TryParse(data[2], out int result);
                    if (isNumber)
                    {
                        engine.Dispalcement = int.Parse(data[2]);
                    }
                    else
                    {
                        engine.Efficincy = data[2];
                    }

                }

                engineList.Add(engine);
            }

            int numberCar = int.Parse(Console.ReadLine());
            for (int i = 0; i < numberCar; i++)
            {
                string[] command = Console.ReadLine()
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();
                string model = command[0];
                string engine = command[1];
                Engine searchEngine = engineList.FirstOrDefault(x => x.Model == engine);

                Car car = new Car();
                car.Model = model;
                car.Engine = searchEngine;

                if (command.Length == 4)
                {
                    int weight = int.Parse(command[2]);
                    string color = command[3];
                    car.Weight = weight;
                    car.Color = color;
                }
                else if (command.Length == 3)
                {
                    bool isNumber = int.TryParse(command[2], out int result);
                    if (isNumber)
                    {
                        int weight = int.Parse(command[2]);
                        car.Weight = weight;
                    }
                    else
                    {
                        string color = command[2];
                        car.Color = color;
                    }
                }
                carList.Add(car);
            }


            foreach (Car car in carList)
            {
                Console.WriteLine($"{car.Model}:");
                Console.WriteLine($" {car.Engine.Model}:");
                Console.WriteLine($"   Power: {car.Engine.Power}");
                                                   
                if (car.Engine.Dispalcement.HasValue)
                {
                    Console.WriteLine($"   Displacement: {car.Engine.Dispalcement}");
                }
                else
                {
                    Console.WriteLine($"   Displacement: n/a");
                }

                if (car.Engine.Efficincy != null)
                {
                    Console.WriteLine($"   Efficiency: {car.Engine.Efficincy}");
                }
                else
                {
                    Console.WriteLine($"   Efficiency: n/a");
                }

                if (car.Weight.HasValue)
                {
                    Console.WriteLine($" Weight: {car.Weight}");

                }
                else
                {
                    Console.WriteLine($" Weight: n/a");

                }

                if (car.Color != null)
                {
                    Console.WriteLine($" Color: {car.Color}");
                }
                else
                {
                    Console.WriteLine($" Color: n/a");
                }

            }

        }
    }
}


//"{CarModel}:
//  { EngineModel}:
    //Power: { EnginePower}
    //Displacement: { EngineDisplacement}
    //Efficiency: { EngineEfficiency}
//Weight: { CarWeight}
//Color: { CarColor}
//"
