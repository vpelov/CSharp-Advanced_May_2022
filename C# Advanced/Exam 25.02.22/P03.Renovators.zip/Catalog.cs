﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Renovators
{
    public class Catalog
    {
        public List<Renovator> renovators;

        public Catalog(string name, int neededRenovators, string project)
        {
            Name = name;
            NeededRenovators = neededRenovators;
            Project = project;
            renovators = new List<Renovator>();
        }

        public string Name{ get; set; }
        public int NeededRenovators { get; set; }
        public string Project { get; set; }

        public int Count => this.renovators.Count;


        public string AddRenovator(Renovator renovator)
        {
            if (renovator.Name == null || renovator.Name == string.Empty || renovator.Type == null || renovator.Type == string.Empty)
            {
                return "Invalid renovator's information.";
            }
            else if (renovators.Count >= this.NeededRenovators)
            {
                return "Renovators are no more needed.";
            }
            else if (renovator.Rate > 350)
            {
                return "Invalid renovator's rate.";
            }

            this.renovators.Add(renovator);
            return $"Successfully added {renovator.Name} to the catalog.";

        }


        public bool RemoveRenovator(string name)
        {
            return this.renovators.Remove(renovators.Find(r => r.Name == name));
        }


        public int RemoveRenovatorBySpecialty(string type)
        {
            int count = 0;
            foreach (var item in this.renovators)
            {
                if (item.Type == type)
                {
                    count++;
                }
            }

            this.renovators.RemoveAll(r => r.Type == type);
            return count;
        }

        public Renovator HireRenovator(string name)
        {

            if (this.renovators.Any(r => r.Name == name))
            {
                Renovator r = this.renovators.FirstOrDefault(r => r.Name == name);
                r.Hired = true;
                return r;                
            }
            return null;
        }

        public List<Renovator> PayRenovators(int days)
        {
            List<Renovator> returnList = new List<Renovator>();

            foreach (var item in this.renovators)
            {
                if (item.Days >= days)
                {
                    returnList.Add(item);
                }
            }

            return returnList;
        }


        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Renovators available for Project {Project}:");
            foreach (var item in this.renovators)
            {
                sb.AppendLine(item.ToString());
            }
            return sb.ToString();
        }

    }
}

