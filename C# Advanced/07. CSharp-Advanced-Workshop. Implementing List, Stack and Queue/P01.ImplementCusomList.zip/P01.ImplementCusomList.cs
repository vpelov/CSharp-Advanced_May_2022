﻿using System;

namespace P01.ImplementCusomList
{
    class Program
    {
        public static void Main(string[] args)
        {
            CustomList vl = new CustomList();

            vl.Add(20);
            vl.Add(30);
            vl.Add(40);
            vl.Add(50);
            vl.Add(60);
            vl.Add(3);
            vl.Add(40);
            vl.Add(45);
            vl.Add(44);
            vl.Add(33);
            vl.Add(11);
            vl.Add(410);
            vl.Add(40);
           
            Console.WriteLine(vl.Count);
            vl.RemoveAt(2);
            Console.WriteLine(vl.Count); 
            vl.RemoveAt(2);
            Console.WriteLine(vl.Count);
            vl.RemoveAt(2);
            Console.WriteLine(vl.Count);
            vl.Insert(6, 7);

            Console.WriteLine(vl.Contains(7));

            
           
        }    

    }
}
