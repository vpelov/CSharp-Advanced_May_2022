﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01.ImplementCusomList
{
    public class CustomList
    {
        private const int Capacity = 2;
        private int[] items;

        public CustomList()
        {
            this.items = new int[Capacity];
        }

        public int Count { get; private set; } = 0;  
        

        public int this[int index]
        {
            get  
            {
                if (index >= this.Count)
                {
                    throw new ArgumentOutOfRangeException();
                }            
                return items[index];
            }
            set
            {
                if (index >= this.Count)
                {
                    throw new ArgumentOutOfRangeException();
                }
                items[index] = value;
            }
        }


        private void Resize()
        {
            int[] newItems = new int[items.Length * 2];
            for (int i = 0; i < this.items.Length; i++)
            {
                newItems[i] = this.items[i];
            }
            items = newItems;
        }

        
        public void Add(int element)
        {
            if (this.Count == this.items.Length)
            {
                this.Resize();
            }

            items[this.Count] = element;
            this.Count++;
        }


        private void Shift(int index)
        {
            for (int i = index; i < this.Count - 1; i++)
            {
                this.items[i] = this.items[i + 1];
            }
        }

        private void Shrink()
        {
            int[] newItems = new int[this.items.Length / 2];
            for (int i = 0; i < newItems.Length; i++)
            {
                newItems[i] = this.items[i];
            }

            this.items = newItems;
        }

        public int RemoveAt(int index)
        {
            if (index < 0 || index >= this.Count)
            {
                throw new ArgumentOutOfRangeException();
            }

            int returnValue = this.items[index];
            this.items[index] = default(int);
            this.Shift(index);
            this.Count--;

            if (this.Count <= this.items.Length / 4)
            {
                this.Shrink();
            }

            return returnValue;
        }
        
        private void ShiftRight(int index)
        {
            if (index < 0 || index > this.Count)
            {
                throw new ArgumentOutOfRangeException();
            }

            for (int i = Count; i > index; i--)
            {
                this.items[i] = this.items[i - 1];
            }


        }

        public void Insert(int index, int element)
        {
            if (index < 0 || index > this.Count)
            {
                throw new ArgumentOutOfRangeException();
            }

            if (this.Count == this.items.Length)
            {
                this.Resize();
            }

            this.ShiftRight(index);
            this.items[index] = element;
            Count++;
        }


        public bool Contains(int element)
        {
            bool isIt = false;

            for (int i = 0; i < this.Count; i++)
            {
                if (this.items[i] == element)
                {
                    isIt = true;
                    break;
                }
            }

            return isIt;
        }


        



    }
}
