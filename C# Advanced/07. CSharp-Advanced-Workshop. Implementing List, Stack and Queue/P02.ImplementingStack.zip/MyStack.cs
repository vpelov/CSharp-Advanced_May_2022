﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P02.ImplementingStack
{
    class MyStack
    {
        private const int capacity = 4;
        private int[] array;
        private int currIndex;

        public MyStack()
        {
            array = new int[capacity];
            currIndex = 0;
        }



        public int Count()
        {
            return this.currIndex;
        }



        private int[] Resize(int[] arr)
        {
            int[] newArr = new int[arr.Length * 2];
            for (int i = 0; i < arr.Length; i++)
            {
                newArr[i] = arr[i];
            }
            return newArr;
        }


        public void Push(int index)
        {
            if (this.array.Length == this.currIndex)
            {
                this.array = Resize(this.array);
            }

            this.array[currIndex] = index;
            currIndex++;
        }


        public int Pop()
        {
            int num = this.array[currIndex - 1];
            this.array[currIndex -1] = default;
            currIndex--;
            return num;
        }


        public int Peek()
        {
           return this.array[currIndex - 1];
        }


    }
}
