﻿using System;

namespace P02.ImplementingStack
{
    class Program
    {
        static void Main(string[] args)
        {
            MyStack vl = new MyStack();
            vl.Push(1);
            vl.Push(2);
            vl.Push(3);
            vl.Push(4);
            vl.Push(5);
            vl.Push(6);
            Console.WriteLine(vl.Count());
            vl.Push(7);
            vl.Push(8);
            vl.Push(9);
            
            Console.WriteLine(vl.Count());
            Console.WriteLine();
            vl.Pop();
            vl.Pop();
            vl.Pop();
            Console.WriteLine();
            Console.WriteLine(vl.Peek());
        }
    }
}
