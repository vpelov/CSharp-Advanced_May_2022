﻿using System;

namespace P03.ImplementingQueue
{
    class Program
    {
        static void Main(string[] args)
        {
            var queue = new MyQueue<int>();

            queue.Enqueue(1);
            queue.Enqueue(2);
            queue.Enqueue(3);

            Console.WriteLine(queue.Count());
            Console.WriteLine(queue);

            queue.Enqueue(4);
            queue.Enqueue(5);

            Console.WriteLine(queue.Count());
            Console.WriteLine(queue);

            queue.Dequeue();
            Console.WriteLine();
            Console.WriteLine(queue);

            queue.Dequeue();
            Console.WriteLine();
            Console.WriteLine(queue);

            queue.Dequeue();
            queue.Enqueue(6);
            Console.WriteLine();
            Console.WriteLine(queue);

            queue.Dequeue();
            Console.WriteLine();
            Console.WriteLine(queue);
        }
    }
}
