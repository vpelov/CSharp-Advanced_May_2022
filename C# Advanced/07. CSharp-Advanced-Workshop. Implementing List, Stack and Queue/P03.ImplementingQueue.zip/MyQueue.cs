﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03.ImplementingQueue
{
    class MyQueue<T>
    {
        private const int capasity = 4;
        private T[] array;
        private int currIndex;


        public MyQueue()
        {
            this.array = new T[capasity];
            this.currIndex = 0;
        }


        private void Resize()
        {
            T[] newArr = new T[this.array.Length * 2];
            for(int i =0; i < this.array.Length; i++)
            {
                newArr[i] = this.array[i];
            }
            this.array = newArr;
        }


        public void Enqueue(T element)
        {
            if (this.currIndex == this.array.Length)
            {
                Resize();
            }

            this.array[currIndex] = element;
            this.currIndex++;
        }

        public void Dequeue()
        {
            T[] newArray = new T[this.array.Length];
            for (int i = 0; i < this.array.Length - 1; i++)
            {
                newArray[i] = this.array[i + 1];
            }
            currIndex--;
            this.array = newArray;
        }


        public int Count()
        {
            return this.currIndex;
        }


        public override string ToString() 
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < this.currIndex; i++)
            {
                sb.AppendLine($"Index: {i} -> Element: {this.array[i]}");
            }
            return sb.ToString();
        }
    }

    
}
