﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<Car> carsList = new List<Car>();
            carsList = GetCar();

            string command = Console.ReadLine();
            while (command != "End")
            {
                string[] cmd = command
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();
                string carModel = cmd[1];
                double amountOfKm = double.Parse(cmd[2]);
                Car currentCar = carsList.First(car => car.Model == carModel);
                currentCar.Drive(currentCar, amountOfKm);
                command = Console.ReadLine();
            }

            foreach (var item in carsList)
            {
                Console.WriteLine($"{item.Model} {item.FuelAmount:f2} {item.TravelledDistance}");
            }
        }


        public static List<Car> GetCar()
        {
            List<Car> returnList = new List<Car>();
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string[] line = Console.ReadLine()
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();
                string model = line[0];
                double fuelAmount = double.Parse(line[1]);
                double fuelConsumptionFor1km = double.Parse(line[2]);
                Car currentCar = new Car(model, fuelAmount, fuelConsumptionFor1km);
                returnList.Add(currentCar);
            }
            return returnList;
        }



    }
}
