﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P08.NewCarSalesman
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Engine> engineList = new List<Engine>();
            engineList = GetEngine();
            List<Car> carList = new List<Car>();
            carList = GetCars(engineList);

            foreach (Car car in carList)
            {
                Console.WriteLine(car);
            }

        }

        public static List<Car> GetCars(List<Engine> engineList)
        {
            List<Car> returnCarList = new List<Car>();
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string[] line = Console.ReadLine()
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();
                string model = line[0];
                string engineModel = line[1];
                Engine currentEngine = engineList.First(engine => engine.Model == engineModel);
                Car currentCar = new Car(model, currentEngine);

                if (line.Length == 2)
                {
                    returnCarList.Add(currentCar);
                }
                else if (line.Length == 3)
                {
                    string unknown = line[2];
                    if (char.IsNumber(unknown[0]))
                    {
                        int weight = int.Parse(line[2]);
                        currentCar.Weight = weight;
                        returnCarList.Add(currentCar);
                    }
                    else
                    {
                        currentCar.Color = unknown;
                        returnCarList.Add(currentCar);
                    }
                }
                else if (line.Length == 4)
                {
                    int weight = int.Parse(line[2]);
                    string color = line[3];
                    currentCar.Weight = weight;
                    currentCar.Color = color;
                    returnCarList.Add(currentCar);
                }               
            }
            return returnCarList;
        }


        public static List<Engine> GetEngine()
        {
            List<Engine> returnList = new List<Engine>();
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string[] line = Console.ReadLine()
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();
                string model = line[0];
                int power = int.Parse(line[1]);
                Engine currentEngine = new Engine(model, power);
                if (line.Length == 2)
                {
                    returnList.Add(currentEngine);
                }
                else if (line.Length == 3)
                {
                    int value;
                    bool isNumber = int.TryParse(line[2], out value);
                    if (isNumber)
                    {
                        currentEngine.Displacement = value;
                        returnList.Add(currentEngine);
                    }
                    else
                    {
                        currentEngine.Efficiency = line[2];
                        returnList.Add(currentEngine);
                    }
                }
                else if (line.Length == 4)
                {
                    int displacement = int.Parse(line[2]);
                    string efficiency = line[3];
                    currentEngine.Displacement = displacement;
                    currentEngine.Efficiency = efficiency;
                    returnList.Add(currentEngine);
                }
            }
            return returnList;
        }
    }
}
