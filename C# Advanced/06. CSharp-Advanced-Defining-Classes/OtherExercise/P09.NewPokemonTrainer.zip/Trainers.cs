﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P09.NewPokemonTrainer
{
    public class Trainers
    {
        public Trainers(string trainerName)
        {
            TrainerName = trainerName;

        }

        public string TrainerName { get; set; }
        public List<Pokemon> PokemonList { get; set; } = new List<Pokemon>();
        public int NumberBadges { get; set; } = 0;
    }
}
