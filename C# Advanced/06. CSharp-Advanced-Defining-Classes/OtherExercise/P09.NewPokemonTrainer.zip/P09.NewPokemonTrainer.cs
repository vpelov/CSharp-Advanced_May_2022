﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P09.NewPokemonTrainer
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Trainers> trainersList = new List<Trainers>();
            CatchPokemon(trainersList);
            PokemonGame(trainersList);
          

            foreach (Trainers trainer in trainersList.OrderByDescending(x => x.NumberBadges))
            {
                Console.WriteLine($"{trainer.TrainerName} {trainer.NumberBadges} {trainer.PokemonList.Count}");
            }

        }

        private static void PokemonGame(List<Trainers> trainersList)
        {
            string line = Console.ReadLine();
            while (line != "End")
            {
                foreach (Trainers trainer in trainersList)
                {
                    if (trainer.PokemonList.Any(pokemon => pokemon.PokemonElement == line))
                    {
                        trainer.NumberBadges++;
                    }
                    else
                    {
                        foreach (Pokemon pokemon in trainer.PokemonList)
                        {
                            pokemon.PokemonHealth -= 10;
                        }

                        if (trainer.PokemonList.Any(pokemon => pokemon.PokemonHealth <= 0))
                        {
                            trainer.PokemonList.RemoveAll(x => x.PokemonHealth <= 0);
                        }
                        
                    }
                }
                line = Console.ReadLine();
            }
        }



        public static void CatchPokemon(List<Trainers> returnTrainersList)
        {
            //List<Trainers> returnTrainersList = new List<Trainers>();
            string line = Console.ReadLine();
            while (line != "Tournament")
            {
                string[] cmd = line
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();
                string trainerName = cmd[0];
                string pokemonName = cmd[1];
                string pokemonElement = cmd[2];
                int pokemonHealth = int.Parse(cmd[3]);                

                Pokemon currentPokemon = new Pokemon(pokemonName, pokemonElement, pokemonHealth);
                if (returnTrainersList.Any(trainer => trainer.TrainerName == trainerName))
                {
                    Trainers currTrainer = returnTrainersList.First(x => x.TrainerName == trainerName);
                    currTrainer.PokemonList.Add(currentPokemon);
                }
                else
                {
                    Trainers currentTrainer = new Trainers(trainerName);
                    currentTrainer.PokemonList.Add(currentPokemon);
                    returnTrainersList.Add(currentTrainer);
                }               
                line = Console.ReadLine();
            }
            //return returnTrainersList;
        }
    }
}
