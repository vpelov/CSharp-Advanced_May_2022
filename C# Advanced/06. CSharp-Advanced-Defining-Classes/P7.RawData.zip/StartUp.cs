﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            List<Car> carsList = GetData(n);

            string command = Console.ReadLine();

            if (command == "fragile")
            {
                foreach (Car car in carsList)
                {
                    if (car.Cargo.Type == "fragile" && car.Tires.Any(x => x.Pressure < 1))
                    {
                        Console.WriteLine($"{car.Model}");
                    }
                }
            }
            else if (command == "flammable")
            {
                foreach (Car car in carsList)
                {
                    if (car.Cargo.Type == "flammable" && car.Engine.Power > 250)
                    {
                        Console.WriteLine($"{car.Model}");
                    }
                }
            }            
        }

        static List<Car> GetData(int n)
        {
            List<Car> carsList = new List<Car>();

            for (int i = 0; i < n; i++)
            {
                string[] iData = Console.ReadLine().Split().ToArray();

                string model = iData[0];
                int engineSpeed = int.Parse(iData[1]);
                int enginePower = int.Parse(iData[2]);
                int cargoWeight = int.Parse(iData[3]);
                string cargoType = iData[4];

                double tire1Pressure = double.Parse(iData[5]);
                int tire1Age = int.Parse(iData[6]);

                double tire2Pressure = double.Parse(iData[7]);
                int tire2Age = int.Parse(iData[8]);

                double tire3Pressure = double.Parse(iData[9]);
                int tire3Age = int.Parse(iData[10]);

                double tire4Pressure = double.Parse(iData[11]);
                int tire4Age = int.Parse(iData[12]);

                Engine engine = new Engine(enginePower, enginePower);
                Cargo cargo = new Cargo(cargoType, cargoWeight);

                Tire tire1 = new Tire(tire1Age, tire1Pressure);
                Tire tire2 = new Tire(tire2Age, tire2Pressure);
                Tire tire3 = new Tire(tire3Age, tire3Pressure);
                Tire tire4 = new Tire(tire4Age, tire4Pressure);

                Tire[] tires = new Tire[4]
                {
                    tire1,
                    tire2,
                    tire3,
                    tire4
                };

                Car car = new Car(model, engine, cargo, tires);
                carsList.Add(car);
            }
            return carsList;
        }
    }
}
