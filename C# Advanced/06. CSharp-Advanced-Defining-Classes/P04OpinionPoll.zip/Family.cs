﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DefiningClasses
{
    public class Family
    {
        public List<Person> People { get; set; } = new List<Person>();


        public void AddMembers(Person person)
        {
            this.People.Add(person);
        }

        public Person GetOldestMember()
        {
            int max = People.Max(x => x.Age);
            return People.First(x => x.Age == max);
        }

    }
}
