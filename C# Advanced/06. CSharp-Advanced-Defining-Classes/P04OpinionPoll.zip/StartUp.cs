﻿using System;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Family newFamily = new Family();
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string[] line = Console.ReadLine()
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();
                string name = line[0];
                int age = int.Parse(line[1]);
                Person person = new Person(name, age);
                newFamily.AddMembers(person);
            }

            Family newMoreThan30 = GetThirtyOld(newFamily);
            foreach (Person person in newMoreThan30.People.OrderBy(x => x.Name))
            {
                Console.WriteLine($"{person.Name} - {person.Age}");
            }

            //Person oldPerson = newFamily.GetOldestMember();
            //Console.WriteLine($"{oldPerson.Name} {oldPerson.Age}");
        }

        public static Family GetThirtyOld(Family newFamily)
        {
            Family returnFamily = new Family();
            foreach (Person person in newFamily.People)
            {
                if (person.Age > 30)
                {
                    returnFamily.AddMembers(person);
                }
            }
            return returnFamily;
        }
    }
}
