﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P06.SpeedRacing
{
    public class Program
    {
        static void Main()
        {
            List<Car> carList = new List<Car>();

            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string[] data = Console.ReadLine().Split();
                string model = data[0];
                double fuelAmount = double.Parse(data[1]);
                double fuelConsumptionPerKilometer = double.Parse(data[2]);

                Car newCar = new Car()
                {
                    Model = model,
                    FuelAmount = fuelAmount,
                    FuelConsumptionPerKilometer = fuelConsumptionPerKilometer,
                    TtravelledDistance = 0
                };
                carList.Add(newCar);
            }

            string command = Console.ReadLine();
            while (command != "End")
            {
                string carModel = command.Split()[1];
                double amountOfKm = double.Parse(command.Split()[2]);
                Car currCar = carList.First(x => x.Model == carModel);

                currCar.Drive(currCar, amountOfKm);

                command = Console.ReadLine();
            }
            foreach (var car in carList)
            {
                Console.WriteLine($"{car.Model} {car.FuelAmount:f2} {car.TtravelledDistance}");
            }            
        }
    }
}
