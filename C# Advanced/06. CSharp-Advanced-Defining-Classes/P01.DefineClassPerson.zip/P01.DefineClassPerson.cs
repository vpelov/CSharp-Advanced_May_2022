﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main()
        {
            Person vp = new Person();
            vp.Name = "Vladimir Pelov";
            vp.Age = 42;

            Console.WriteLine("Name: " + vp.Name + " Age: " + vp.Age);


        }
    }
}
