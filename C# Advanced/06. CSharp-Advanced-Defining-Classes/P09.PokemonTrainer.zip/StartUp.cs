﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GameField
{
    class StartUp
    {
        static void Main(string[] args)
        {
            List<Trainers> trainersList = GetTrainers();
            string cmd = Console.ReadLine();
            while (cmd != "End")
            {                
                foreach (Trainers trainer in trainersList)
                {
                    if (trainer.PokemonCollection.Any(x => x.Element == cmd))
                    {
                        trainer.NumberOfBadges++;
                    }
                    else
                    {
                        foreach (Pokemon pokemon in trainer.PokemonCollection)
                        {
                            pokemon.Health -= 10;
                            if (pokemon.Health <= 0) ;                           
                        }
                    }

                    if (trainer.PokemonCollection.Any(x => x.Health <= 0))
                    {
                        Pokemon pok = trainer.PokemonCollection.First(x => x.Health <= 0);
                        trainer.PokemonCollection.Remove(pok);
                    }
                }
                cmd = Console.ReadLine();
            }            
            trainersList = trainersList.OrderByDescending(x => x.NumberOfBadges).ToList();
            foreach (var item in trainersList)
            {
                Console.WriteLine($"{item.Name} {item.NumberOfBadges} {item.PokemonCollection.Count}");
            }
        }


        public static List<Trainers> GetTrainers()
        {
            List<Trainers> returnTrainersList = new List<Trainers>();
            string cmd = Console.ReadLine();
            while (cmd != "Tournament")
            {
                string[] command = cmd.Split(' ', StringSplitOptions.RemoveEmptyEntries).ToArray();
                string trainerName = command[0];
                string pokemonName = command[1];
                string pokemonElement = command[2];
                int pokemonHealth = int.Parse(command[3]);
                Pokemon currentPokemon = new Pokemon(pokemonName, pokemonElement, pokemonHealth);
                if (returnTrainersList.Any(x => x.Name == trainerName))
                {
                    Trainers treiner = returnTrainersList.First(x => x.Name == trainerName);
                    treiner.AddPokemon(currentPokemon);
                }
                else
                {
                    Trainers currentTrainer = new Trainers(trainerName);
                    currentTrainer.AddPokemon(currentPokemon);
                    returnTrainersList.Add(currentTrainer);
                }
                cmd = Console.ReadLine();
            }
            return returnTrainersList;
        }
    }
}
