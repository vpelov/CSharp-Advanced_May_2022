﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Car newCar = new Car();

            newCar.Model = "Kuga";
            newCar.Make = "Ford";
            newCar.Year = 2011;

            Console.WriteLine($"Make: {newCar.Make}\nModel: {newCar.Model}\nYear: {newCar.Year}");
        }
    }
}
