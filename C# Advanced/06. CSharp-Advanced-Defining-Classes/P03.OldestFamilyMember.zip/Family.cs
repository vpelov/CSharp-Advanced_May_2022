﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace DefiningClasses
{
    public class Family
    {
        List<Person> peopleList;


        public Family()
        {
            this.peopleList = new List<Person>();
        }


        public void AddMember(Person member)
        {
            this.peopleList.Add(member);
        }

    public Person GetOldestMember()
    {
        int maxAge = int.MinValue;
        maxAge = peopleList.Max(x => x.Age);
        return peopleList.First(x => x.Age == maxAge);
    }

}
}
