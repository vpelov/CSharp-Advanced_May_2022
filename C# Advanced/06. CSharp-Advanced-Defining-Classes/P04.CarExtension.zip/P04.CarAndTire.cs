﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
           

            var engine = new Engine(560, 6300);

            var tires = new Tire[] 
                {
                new Tire(2, 2.1),
                new Tire(4, 2.2),
                new Tire(3, 2.3),
                new Tire(19, 2.2)
                };


            var car = new Car("Lamborghini", "Urus", 2020, 250, 10, engine, tires);
            Console.WriteLine(car.WhoAmI());
        }
    }
}
