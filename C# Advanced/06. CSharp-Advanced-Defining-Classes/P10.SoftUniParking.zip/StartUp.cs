﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SoftUniParking
{
    public class StartUp
    {
        public static void Main()
        {
            

        }
    }
}
