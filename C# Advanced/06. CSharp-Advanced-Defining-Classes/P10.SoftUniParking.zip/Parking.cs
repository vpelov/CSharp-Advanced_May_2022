﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SoftUniParking
{
    public class Parking
    {
        public Parking(int capacity)
        {
            Capacity = capacity;
        }

        public List<Car> CarList { get; set; } = new List<Car>();

        public int Capacity { get; set; }

        public int Count
        {
            get { return CarList.Count; }
        }



        public void AddCar(Car car)
        {
            if (CarList.Any(x => x.RegistrationNumber == car.RegistrationNumber))
            {
                Console.WriteLine("Car with that registration number, already exists!");
            }
            else if (Capacity <= CarList.Count)
            {
                Console.WriteLine("Parking is full!");
            }
            else
            {
                CarList.Add(car);
                Console.WriteLine($"Successfully added new car {car.Make} {car.RegistrationNumber}");
            }
        }


        public void RemoveCar(string registrationNumber)
        {
            if (!CarList.Any(x => x.RegistrationNumber == registrationNumber))
            {
                Console.WriteLine("Car with that registration number, doesn't exist!");
            }
            else
            {
                Car removeCar = CarList.First(x => x.RegistrationNumber == registrationNumber);
                CarList.Remove(removeCar);
                Console.WriteLine($"Successfully removed {registrationNumber}");
            }
        }


        public Car GetCar(string registrationNumber)
        {
            Car returnCar;
            return returnCar = CarList.First(x => x.RegistrationNumber == registrationNumber);
        }


        public void RemoveSetOfRegistrationNumber(List<string> registrationNumber)
        {
            foreach (var item in registrationNumber)
            {
                if (CarList.Any(x => x.RegistrationNumber == item))
                {
                    Car removeCar = CarList.First(x => x.RegistrationNumber == item);
                    CarList.Remove(removeCar);
                }
            }
        }

    }
}
