﻿using System;

namespace DateModifier
{
    public class Program
    {
        static void Main()
        {
            DateTime curr = DateTime.Parse(Console.ReadLine());
            DateTime currTwo = DateTime.Parse(Console.ReadLine());

            DateModifier date = new DateModifier(curr, currTwo);

            date.GetDiffDate(date);
        }
    }
}
