﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DateModifier
{
    public class DateModifier
    {

        public DateTime One { get; set; }

        public DateTime Two { get; set; }

        public DateModifier(DateTime one, DateTime two)
        {
            this.One = one;
            this.Two = two;
        }



        public void GetDiffDate(DateModifier curr)
        {
            TimeSpan duration = curr.One - curr.Two;
            int day = Math.Abs(duration.Days);  
            
            Console.WriteLine(day);
        }
    }
}
