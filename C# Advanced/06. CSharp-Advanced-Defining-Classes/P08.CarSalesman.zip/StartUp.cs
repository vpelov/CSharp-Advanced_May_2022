﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Deffender
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<Engine> engineList = new List<Engine>();
            engineList = GetEngine();

            List<Car> carList = new List<Car>();
            carList = GetCars(engineList);

            foreach (Car car in carList)
            {
                Console.WriteLine(car.ToString());                
            }

        }


        public static List<Engine> GetEngine()
        {
            int n = int.Parse(Console.ReadLine());
            if (n <= 0)
            {
                Console.WriteLine("Invalid input: N ");
                throw new NotImplementedException();
            }
            List<Engine> returnEngineList = new List<Engine>();

            for (int i = 0; i < n; i++)
            {
                string[] command = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries).ToArray();
                string model = command[0];
                int power = int.Parse(command[1]);

                if (command.Length == 2)
                {
                    Engine currentEngine = new Engine(model, power);
                    returnEngineList.Add(currentEngine);
                }
                else if (command.Length == 3)
                {
                    string unknown = command[2];
                    int num;
                    bool isNumber = int.TryParse(unknown, out num);
                    if (isNumber == true) // it is Number
                    {
                        Engine currentEngine = new Engine(model, power);
                        currentEngine.Displacement = num;
                        returnEngineList.Add(currentEngine);
                    }
                    else                  // it is String
                    {
                        Engine currentEngine = new Engine(model, power);
                        currentEngine.Efficiency = unknown;
                        returnEngineList.Add(currentEngine);
                    }
                }
                else if (command.Length == 4)
                {
                    Engine currentEngine = new Engine(model, power);
                    currentEngine.Displacement = int.Parse(command[2]);
                    currentEngine.Efficiency = command[3];
                    returnEngineList.Add(currentEngine);
                }
            }
            return returnEngineList;
        }


        public static List<Car> GetCars(List<Engine> engineList)
        {
            List<Car> returnCarsList = new List<Car>();
            int m = int.Parse(Console.ReadLine());
            if (m <= 0)
            {
                Console.WriteLine("Invalid input: M ");
                throw new NotImplementedException();
            }

            for (int i = 0; i < m; i++)
            {
                string[] command = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries).ToArray();
                string model = command[0];
                string engine = command[1];
                Engine curreneEngine = engineList.First(x => x.Model == engine);
                if (command.Length == 2)
                {
                    Car currentCar = new Car(model, curreneEngine);
                    returnCarsList.Add(currentCar);
                }
                else if (command.Length == 3)
                {
                    string unknown = command[2];
                    int number;
                    bool isNumber = int.TryParse(unknown, out number);
                    if (isNumber) // it is a number
                    {
                        Car currentCar = new Car(model, curreneEngine);
                        currentCar.Weight = number;
                        returnCarsList.Add(currentCar);

                    }
                    else  // is not a number
                    {
                        Car currentCar = new Car(model, curreneEngine);
                        currentCar.Color = unknown;
                        returnCarsList.Add(currentCar);
                    }
                }
                else if (command.Length == 4)
                {
                    Car currentCar = new Car(model, curreneEngine);
                    currentCar.Weight = int.Parse(command[2]);
                    currentCar.Color = command[3];
                    returnCarsList.Add(currentCar);
                }
            }
            return returnCarsList;
        }

    }
}
