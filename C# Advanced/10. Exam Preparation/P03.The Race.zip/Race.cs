﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TheRace
{
    public class Race
    {
        public List<Racer> data;

        public Race(string name, int capacity)
        {
            Name = name;
            Capacity = capacity;
            data = new List<Racer>();
        }

        public string Name { get; set; }
        public int Capacity { get; set; }
        public int Count => data.Count;



        public void Add(Racer Racer)
        {
            if (this.data.Count < this.Capacity)
            {
                this.data.Add(Racer);
            }
        }


        public bool Remove(string name)
        {
            if (this.data.Any(x => x.Name == name))
            {
                this.data.RemoveAll(x => x.Name == name);
                return true;
            }
            return false;
        }


        public Racer GetOldestRacer()
        {
            //int bigAge = this.data.Select(x => x.Age).Max();
            int bigAge = this.data.Max(x => x.Age);   //??????????????????
            return this.data.First(b => b.Age == bigAge);
        }


        public Racer GetRacer(string name)
        {
            return this.data.First(x => x.Name == name);
        }


        public Racer GetFastestRacer()
        {
            int speedCar = this.data.Max(x => x.Car.Speed);     //??????????????????
            return this.data.First(x => x.Car.Speed == speedCar);
        }


        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Racers participating at {this.Name}:");
            foreach (var item in this.data)
            {
                sb.AppendLine(item.ToString());
            }
            return sb.ToString().TrimEnd();
        }

    }
}


