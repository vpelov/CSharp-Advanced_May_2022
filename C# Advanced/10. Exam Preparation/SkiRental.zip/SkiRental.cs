﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SkiRental
{
    class SkiRental
    {
        public List<Ski> data;

        public SkiRental(string name, int capacity)
        {
            Name = name;
            Capacity = capacity;
            data = new List<Ski>();
        }

        public string Name { get; set; }
        public int Capacity { get; set; }
        public int Count => this.data.Count;

        public void Add(Ski ski)
        {
            if (this.Capacity > this.data.Count)
            {
                this.data.Add(ski);
            }
        }


        public bool Remove(string manufacturer, string model)
        {
            return this.data.Remove(data.Find(s => s.Manufacturer == manufacturer && s.Model == model));
            //foreach (var item in this.data)
            //{
            //    if (item.Manufacturer == manufacturer && item.Model == model)
            //    {
            //        this.data.Remove(item);
            //        return true;
            //        break;
            //    }
            //}
            //return false;

        }


        public Ski GetNewestSki()
        {
            if (this.data.Count == 0)
            {
                return null;
            }

            int newetSki = 0;
            foreach (var item in this.data)
            {
                if (item.Year > newetSki)
                {
                    newetSki = item.Year;
                }
            }
            return this.data.Find(s => s.Year == newetSki);
        }


        public Ski GetSki(string manufacturer, string model)
        {
            return this.data.Find(s => s.Manufacturer == manufacturer && s.Model == model);  //?????
        }


        public string GetStatistics()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"The skis stored in {this.Name}:");

            foreach (var item in this.data)
            {
                sb.AppendLine(item.ToString());
            }
            return sb.ToString();
        }

    }
}


//o "The skis stored in {Ski Rental Name}:
//{ Ski1}
//{ Ski2}
//(…)"
