﻿using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FishingNet
{
    public class Net
    {
        public List<Fish> Fish;
       

        public Net(string material, int capacity)
        {
            Material = material;
            Capacity = capacity;
            Fish = new List<Fish>();
        }

        public string Material { get; set; }
        public int Capacity { get; set; }
        public int Count => Fish.Count;



        public string AddFish(Fish fish)
        {
            if (string.IsNullOrWhiteSpace(fish.FishType))
            {
                return "Invalid fish.";
            }
            else if (fish.Length <= 0 || fish.Weight <= 0)
            {
                return "Invalid fish.";
            }
            else if (this.Capacity <= Fish.Count)
            {
                return "Fishing net is full.";
            }
            this.Fish.Add(fish);
            return $"Successfully added {fish.FishType} to the fishing net.";
        }


        public bool ReleaseFish(double weight)
        {
            if (Fish.Any(x => x.Weight == weight))
            {
                Fish.RemoveAll(x => x.Weight == weight);
                return true;                               // ????????
            }
            return false;
        }


        public Fish GetFish(string fishType)
        {
            return Fish.Find(x => x.FishType == fishType);
        }


        public Fish GetBiggestFish()
        {
            double longFish = int.MinValue;
            foreach (var item in this.Fish)
            {
                if (item.Length > longFish)
                {
                    longFish = item.Length;
                }
            }
            return Fish.Find(x => x.Length == longFish);
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Into the {this.Material}:");
            foreach (var item in Fish)
            {
                sb.AppendLine($"{item}");
            }

            return sb.ToString();
        }

    }
}

