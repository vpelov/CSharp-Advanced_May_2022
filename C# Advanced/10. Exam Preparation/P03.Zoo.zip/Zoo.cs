﻿using System.Collections.Generic;
using System.Linq;

namespace Zoo
{
    public class Zoo
    {
        public List<Animal> Animals;

        public Zoo(string name, int capacity)
        {
            Name = name;
            Capacity = capacity;
            Animals = new List<Animal>();
        }

        public string Name { get; set; }
        public int Capacity { get; set; }
        public int Count => Animals.Count;

        public string AddAnimal(Animal animal)
        {
            if (animal.Species == null || animal.Species == string.Empty)
            {
                return "Invalid animal species.";
            }
            else if (animal.Diet != "herbivore" && animal.Diet != "carnivore")
            {
                return "Invalid animal diet.";
            }
            else if (Animals.Count >= this.Capacity)
            {
                return "The zoo is full.";
            }
            else
            {
                this.Animals.Add(animal);
                return $"Successfully added {animal.Species} to the zoo.";
            }
        }

        public int RemoveAnimals(string species)
        {
            int count = 0;
            if (Animals.Count == 0)
            {
                return 0;
            }
            else
            {
                foreach (var item in this.Animals)
                {
                    if (item.Species == species)
                    {
                        count++;
                    }
                }
                Animals.RemoveAll(x => x.Species == species);
                return count;
            }
        }


        public List<Animal> GetAnimalsByDiet(string diet)
        {
            List<Animal> returnList = new List<Animal>();
            foreach (var item in this.Animals)
            {
                if (item.Diet == diet)
                {
                    returnList.Add(item);
                }
            }
            return returnList;
        }


        public Animal GetAnimalByWeight(double weight)
        {
            Animal animal = this.Animals.First(x => x.Weight == weight);
            return animal;
        }


        public string GetAnimalCountByLength(double minimumLength, double maximumLength)
        {
            List<Animal> sortAnimalByLenght = new List<Animal>();
            foreach (var item in this.Animals)
            {
                if (item.Length >= minimumLength && item.Length <= maximumLength)
                {
                    sortAnimalByLenght.Add(item);
                }
            }

            return $"There are {sortAnimalByLenght.Count} animals with a length between {minimumLength} and {maximumLength} meters.";

        }

    }
}


