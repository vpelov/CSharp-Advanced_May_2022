﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace Parking
{
    class Parking
    {
        public List<Car> data;

        public Parking(string type, int capacity)
        {
            Type = type;
            Capacity = capacity;
            data = new List<Car>();
        }

        public string Type { get; set; }
        public int  Capacity { get; set; }

        public int Count => this.data.Count;


        public void Add(Car car)
        {
            if (this.Capacity > this.data.Count)
            {
                this.data.Add(car);
            }
        }


        public bool Remove(string manufacturer, string model)
        {
            return this.data.Remove(data.Find(c => c.Manufacturer == manufacturer && c.Model == model));
        }


        public Car GetLatestCar()
        {
            if (this.data.Count == 0)
            {
                return null;
            }

            int latestYear = 0;
            foreach (var item in this.data)
            {
                if (item.Year > latestYear)
                {
                    latestYear = item.Year; 
                }
            }
            return this.data.Find(c => c.Year == latestYear);
        }


        public Car GetCar(string manufacturer, string model)
        {
            foreach (var item in this.data)
            {
                if (item.Manufacturer == manufacturer && item.Model == model)
                {
                    return item;
                }
            }
            return null;
        }

        public string GetStatistics()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"The cars are parked in {this.Type}:");
            foreach (var item in this.data)
            {
                sb.AppendLine(item.ToString());
            }
            return sb.ToString();
        }
    }
}


