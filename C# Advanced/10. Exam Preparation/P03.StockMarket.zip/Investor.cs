﻿using System.Collections.Generic;
using System;
using System.Linq;
using System.Text;

namespace StockMarket
{
    public class Investor
    {
        private List<Stock> portfolio;
        
        public string FullName { get; set; }
        public string EmailAddress { get; set; }
        public decimal MoneyToInvest { get; set; }
        public string BrokerName { get; set; }
        public int Count => portfolio.Count;

        public Investor(string fullName, string emailAddress, decimal moneyToInvest, string brokerName)
        {
            FullName = fullName;
            EmailAddress = emailAddress;
            MoneyToInvest = moneyToInvest;
            BrokerName = brokerName;
            this.portfolio = new List<Stock>();
        }

        
        public void BuyStock(Stock stock)
        {
            if (stock.MarketCapitalization > 10000 && this.MoneyToInvest >= stock.PricePerShare)
            {
                this.portfolio.Add(stock);
                this.MoneyToInvest -= stock.MarketCapitalization;
            }
        }

        public string SellStock(string companyName, decimal sellPrice)
        {
            if (!this.portfolio.Any(s => s.CompanyName == companyName))
            {
                return $"{companyName} does not exist.";             
            }

            Stock stock = portfolio.First(x => x.CompanyName == companyName);
            if (stock.PricePerShare < sellPrice)
            {
                return $"Cannot sell {companyName}.";
            }

            this.portfolio.Remove(stock);
            this.MoneyToInvest += sellPrice;
            return $"{companyName} was sold.";
        }

        public Stock FindStock(string companyName)
        {
            if (this.portfolio.Any(s => s.CompanyName == companyName))
            {
                Stock stock = portfolio.Find(s => s.CompanyName == companyName);
                return stock;
            }
            return null;
        }

        public Stock FindBiggestCompany()
        {
            if (this.portfolio.Count != 0)
            {
                string companyName = string.Empty;
                decimal capital = int.MinValue;
                foreach (var item in this.portfolio)
                {
                    if (item.MarketCapitalization > capital)
                    {
                        capital = item.MarketCapitalization;
                        companyName = item.CompanyName;
                    }
                }
                return this.portfolio.First(s => s.CompanyName == companyName);
            }
            return null;
        }

        public string InvestorInformation()
        {
            StringBuilder sb = new StringBuilder();
           sb.AppendLine($"The investor {this.FullName} with a broker {this.BrokerName} has stocks:");
            foreach (var item in this.portfolio)
            {
                sb.AppendLine($"{item}");
            }

            return sb.ToString();
        }
    }
}


