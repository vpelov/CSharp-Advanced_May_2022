﻿using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drones
{
    public class Airfield
    {
        public List<Drone> Drones { get; set; }
        public string Name { get; set; }
        public int Capacity { get; set; }
        public double LandingStrip { get; set; }

        public Airfield(string name, int capacity, double landingStrip)
        {
            Name = name;
            Capacity = capacity;
            LandingStrip = landingStrip;
            Drones = new List<Drone>();
        }

        public int Count => this.Drones.Count;         

        public string AddDrone(Drone drone)
        {
            if (drone.Brand == null || drone.Brand == string.Empty || drone.Name == null || drone.Name == string.Empty)
            {
                return "Invalid drone.";
            }
            else if (drone.Range < 5 || drone.Range >15)
            {
                return "Invalid drone.";
            }
            else if (Drones.Count >= this.Capacity)
            {
                return "Airfield is full.";
            }
            else
            {
                this.Drones.Add(drone);
                return $"Successfully added {drone.Name} to the airfield.";
            }


        }

        public bool RemoveDrone(string name)
        {
            if (this.Drones.Any(x => x.Name == name))
            {
                this.Drones.RemoveAll(x => x.Name == name);
                return true;
            }
            else
            {
                return false;
            }
        }

        public int RemoveDroneByBrand(string brand)        //???????????????????????????
        {
            if (this.Drones.Any(x => x.Brand == brand))
            {
                return this.Drones.RemoveAll(x => x.Brand == brand);
            }
            else
            {
                return 0;
            }
        }

        public Drone FlyDrone(string droneName)
        {
            if (Drones.Any(x => x.Name == droneName))
            {
                Drone currentDrone = Drones.First(x => x.Name == droneName);
                currentDrone.Avilable = false;
                return currentDrone;
            }
            return null;
        }


        public List<Drone> FlyDronesByRange(int range)
        {
            List<Drone> returnList = this.Drones.Where(x => x.Range >= range).ToList();
            return returnList;
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Drones available at {this.Name}");
            foreach (var item in this.Drones)
            {
                if (item.Avilable == false)
                {
                    sb.AppendLine(item.Name);
                }
            }

            return sb.ToString();
        }


    }
}


//o "Drones available at {airfieldName}:
//{ Drone1}
//{ Drone2}
//(…)"
