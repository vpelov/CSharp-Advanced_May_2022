﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace P05.GenericCountMetodStrings
{
    public class Box<T> where T : IComparable
    {
        public List<T> array;

        public Box()
        {
            this.array = new List<T>();
        }


        public void Add(T element)
        {
            this.array.Add(element);
        }


        public int CompareMetod( T element)
        {
            int count = 0;
            foreach (T item in this.array)
            {
                if (element.CompareTo(item) < 0)
                {
                    count++;
                }
            }
            return count;
        }


    }
}
