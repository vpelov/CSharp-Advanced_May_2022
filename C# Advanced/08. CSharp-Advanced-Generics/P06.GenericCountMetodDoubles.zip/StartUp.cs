﻿using System;

namespace P05.GenericCountMetodStrings
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Box<double> box = new Box<double>();
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                double str = double.Parse( Console.ReadLine());
                box.Add(str);
            }

            double element = double.Parse(Console.ReadLine());
            int result = box.CompareMetod(element);
            Console.WriteLine(result);

        }
    }
}
