﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericArrayCreator
{
    class ArrayCreator
    {

        public static T[] Create<T>(int lenght, T data)
        {
            T[] newArraw = new T[lenght];
            for (int i = 0; i < newArraw.Length; i++)
            {
                newArraw[i] = data;
            }

            return newArraw;
        }

    }
}
