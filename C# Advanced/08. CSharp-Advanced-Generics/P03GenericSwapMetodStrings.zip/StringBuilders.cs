﻿namespace P03GenericSwapMetodStrings
{
    internal class StringBuilders
    {
        public StringBuilders()
        {
        }
    }
}