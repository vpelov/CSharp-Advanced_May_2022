﻿using System;
using System.Linq;

namespace P03GenericSwapMetodStrings
{
    class Program
    {
        static void Main(string[] args)
        {
            Box<string> box = new Box<string>();

            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string str = Console.ReadLine();
                box.Add(str);
            }

            string command = Console.ReadLine();
            int first = int.Parse(command.Split(' ', StringSplitOptions.RemoveEmptyEntries).ToArray()[0]);
            int second = int.Parse(command.Split(' ', StringSplitOptions.RemoveEmptyEntries).ToArray()[1]);

            box.Swap(first, second);
            Console.WriteLine(box);

        }
    }
}
