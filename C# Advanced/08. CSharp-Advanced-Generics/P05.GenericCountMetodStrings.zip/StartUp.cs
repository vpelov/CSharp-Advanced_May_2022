﻿using System;

namespace P05.GenericCountMetodStrings
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Box<string> box = new Box<string>();
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string str = Console.ReadLine();
                box.Add(str);
            }

            string element = Console.ReadLine();
            int result = box.CompareMetod(element);
            Console.WriteLine(result);

        }
    }
}
