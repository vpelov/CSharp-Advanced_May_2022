﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03GenericSwapMetodStrings
{
    class Box<T>
    {
        public List<T> value;

        public Box()
        {
            this.value = new List<T>();
        }

        public void Add(T item)
        {
            this.value.Add(item);
        }


        public void Swap(int first, int second)
        {
            T element = this.value[first];
            this.value[first] = this.value[second];
            this.value[second] = element;
        }



        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
                       
            foreach (var item in this.value)
            {
                sb.AppendLine($"{item.GetType()}: {item}");
            }
            return sb.ToString();
        }

    }
}
