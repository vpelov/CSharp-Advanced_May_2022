﻿using System;
using System.Linq;

namespace P03GenericSwapMetodStrings
{
    class Program
    {
        static void Main(string[] args)
        {
            Box<int> box = new Box<int>();

            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                int str = int.Parse(Console.ReadLine());
                box.Add(str);
            }

            string command = Console.ReadLine();
            int first = int.Parse(command.Split(' ', StringSplitOptions.RemoveEmptyEntries).ToArray()[0]);
            int second = int.Parse(command.Split(' ', StringSplitOptions.RemoveEmptyEntries).ToArray()[1]);

            box.Swap(first, second);
            Console.WriteLine(box);

        }
    }
}
