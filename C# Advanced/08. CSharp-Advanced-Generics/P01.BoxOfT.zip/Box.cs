﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BoxOfT
{
    public class Box<T>
    {        
        private const int capacity = 4;
        private T[] array;
        public int count { get; private set; }


        public Box()
        {
            this.array = new T[capacity];
            this.count = 0;
        }


        public void Add(T element)
        {
            if (this.array.Length == 0)
            {
                throw new ArgumentOutOfRangeException();
            }

            array[count] = element;
            count++;
        }


        public T Remove()
        {
            if (this.array.Length == 0)
            {
                throw new ArgumentOutOfRangeException();
            }

            T returnElement = this.array[count - 1];
            this.array[count - 1] = default;
            count--;
            return returnElement;
        }


    }
}
