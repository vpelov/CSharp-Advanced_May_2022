﻿using System;
using System.Linq;

namespace P08.Threeuple
{
    class StartUp
    {
        static void Main(string[] args)
        {

            string[] line = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries).ToArray();
            var info = new Threeuple<string, string, string>(line[0] + " " + line[1], line[2], line[3]);
            Console.WriteLine(info);


            string[] line1 = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries).ToArray();
            string name = line1[0];
            int age = int.Parse(line1[1]);
            bool isDrunk = line1[2] == "drunk" ? true : false;
            var info1 = new Threeuple<string, int, bool>(name, age, isDrunk);
            Console.WriteLine(info1);

            string[] line2 = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries).ToArray();
            var info2 = new Threeuple<string, double, string>(line2[0], double.Parse(line2[1]), line2[2]);
            Console.WriteLine(info2);
        }
    }
}
