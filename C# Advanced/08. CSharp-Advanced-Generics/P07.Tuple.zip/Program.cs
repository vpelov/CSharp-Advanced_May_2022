﻿using System;
using System.Linq;

namespace P07.Tuple
{
    public class Program
    {
        static void Main(string[] args)
        {
            
                string[] command = Console.ReadLine()
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();
                string first = command[0] + " " + command[1];
                string second = command[2];
                Tuple<string, string> tupleOne = new Tuple<string, string>(first, second);
                Console.WriteLine(tupleOne.ToString());


                string[] command1 = Console.ReadLine()
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();
                string first1 = command1[0];
                int second1 = int.Parse(command1[1]);
                Tuple<string, int> tupleTwo = new Tuple<string, int>(first1, second1);
                Console.WriteLine(tupleTwo.ToString());


                string[] command2 = Console.ReadLine()
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();
                double first2 = double.Parse(command2[0]);
                double second2 = double.Parse(command2[1]);
                Tuple<double, double> tupleThree = new Tuple<double, double>(first2, second2);
                Console.WriteLine(tupleThree.ToString());
            
        }
    }
}
