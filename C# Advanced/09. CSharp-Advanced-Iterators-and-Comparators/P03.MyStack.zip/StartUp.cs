﻿using System;
using System.Linq;

namespace P03.MyStack
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string[] inputData = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries).ToArray();

            MyStack<string> stack = new MyStack<string>();

            while (inputData[0] != "END")
            {
                if (inputData[0] == "Push")
                {
                    stack.Push(inputData.Skip(1).Select(e => e.Split(",").First()).ToArray());
                }
                else if (inputData[0] == "Pop")
                {
                    string s = stack.Pop();
                }
                inputData = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries).ToArray();
            }

            foreach (var item in stack)
            {
                Console.WriteLine(item);
            }

            foreach (var item in stack)
            {
                Console.WriteLine(item);
            }

        }
    }
}
