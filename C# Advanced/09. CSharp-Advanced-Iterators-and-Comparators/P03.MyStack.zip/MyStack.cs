﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace P03.MyStack
{
    public class MyStack<T> : IEnumerable<T>
    {
        private List<T> stack;
        private int index;

        //public MyStack(params T[] array)
        //{
        //    this.stack = new List<T>(array);  
        //    this.index = 0;
        //}

        public MyStack()
        {
            this.stack = new List<T>();
            this.index = - 1;
        }

        public void Push(params T[] currentArray)
        {
            foreach (var item in currentArray)
            {
                this.stack.Add(item);
                this.index++;
            }
        }

        public T Pop()
        {
            if (this.index < 0)
            {
                Console.WriteLine("No elements");
                return default;
            }
            else
            {
                T element = this.stack[this.index];
                stack.RemoveAt(this.index);
                this.index--;
                return element;         
            }
        }

        public IEnumerator<T> GetEnumerator()
        {
            for (int i = this.stack.Count - 1; i >= 0; i--)
            {
                yield return this.stack[i];
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
           return this.GetEnumerator();
        }
    }
}
