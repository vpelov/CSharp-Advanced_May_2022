﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P05.ComparingObjects
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<Person> personList = new List<Person>();
            string command = Console.ReadLine();
            while (command != "END")
            {
                string[] line = command
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();
                Person person = new Person(line[0], int.Parse(line[1]), line[2]);
                personList.Add(person);
                command = Console.ReadLine();
            }

            int number = int.Parse(Console.ReadLine());

            int equal = 0;
            int notEqual = 0;

            foreach (var item in personList)
            {
                int result = personList[number - 1].CompareTo(item);
                if (result == 0)
                {
                    equal++;
                }
                else
                {
                    notEqual++;
                }
            }

            if (equal <= 1)
            {
                Console.WriteLine("No matches");
            }
            else
            {
                Console.WriteLine($"{equal} {notEqual} {personList.Count}");
            }


        }
    }
}
