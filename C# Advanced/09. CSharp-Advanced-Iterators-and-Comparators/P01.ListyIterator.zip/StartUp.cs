﻿using System;
using System.Linq;

namespace P01.ListyIterators
{
    class StartUp
    {
        static void Main(string[] args)
        {

            string[] command = Console.ReadLine()
                .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                .ToArray();

            string[] array = new string[command.Length - 1];
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = command[i + 1];
            }

            ListyIterator<string> iterator = new ListyIterator<string>(array);

            string line = Console.ReadLine();

            while (line != "END")
            {
                string[] cmd = line
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();

                if (cmd[0] == "Move")
                {
                    bool result = iterator.Move();
                    Console.WriteLine(result);
                }
                else if (cmd[0] == "HasNext")
                {
                    bool resultTwo = iterator.HasNext();
                    Console.WriteLine(resultTwo);
                }
                else if (cmd[0] == "Print")
                {
                    iterator.Print();
                }

                line = Console.ReadLine();
            }



        }
    }
}
