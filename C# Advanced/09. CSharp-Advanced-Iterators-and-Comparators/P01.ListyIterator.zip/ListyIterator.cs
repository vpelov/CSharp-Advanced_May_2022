﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01.ListyIterators
{
    public class ListyIterator<T>
    {
        private List<T> list;
        private int index;

        public ListyIterator(params T[] items)
        {
            this.list = new List<T>(items);
            this.index = 0;
        }

        public bool Move() 
        {
            if (this.index < this.list.Count - 1)
            {
                this.index++;
                return true;
            }
            return false;        
        }

        public bool HasNext()
        {
            if (this.index + 1 < this.list.Count)
            {
                return true;
            }
            return false;
        }

        public void Print()
        {
            if (this.list == null || this.index >= this.list.Count)
            {
                Console.WriteLine("Invalid Operation!");
            }
            else
            {
                Console.WriteLine($"{this.list[this.index]}");
            }
        }
    }
}
