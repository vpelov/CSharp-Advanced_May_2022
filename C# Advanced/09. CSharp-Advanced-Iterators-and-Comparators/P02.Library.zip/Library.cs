﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace IteratorsAndComparators
{
    public class Library : IEnumerable<Book>
    {
        public List<Book> Books;

        public Library(params Book[] books)
        {
            this.Books = new List<Book>(books);
        }

        public IEnumerator<Book> GetEnumerator()
        {
            return Books.GetEnumerator();
        }
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();




        private class LibraryIterator : IEnumerator<Book>
        {
            private List<Book> books;
            private int index = 0;
            

            public Book Current => this.books[index];

            public bool MoveNext()
            {
                if (index < books.Count)
                {
                    return true;
                }
                return false;
            }



            object IEnumerator.Current => this.Current;
            public void Dispose()
            {
            }
            public void Reset()
            {
            }
        }

    }


    
}
