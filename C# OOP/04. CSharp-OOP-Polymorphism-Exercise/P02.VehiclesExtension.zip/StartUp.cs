﻿using P01.Vehicles.Core;
using P01.Vehicles.Models;
using System;
using System.Linq;

namespace P01.Vehicles
{
    public class StartUp
    {
        static void Main()
        {
           
            string[] dataCat = Console.ReadLine()
                .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                .ToArray();
            double fuel = double.Parse(dataCat[1]);
            double consumption = double.Parse(dataCat[2]);
            double tankCapacity = double.Parse(dataCat[3]);
            Vehicle currentCar = new Car(fuel, consumption, tankCapacity);

            string[] dataTruck = Console.ReadLine()
               .Split(' ', StringSplitOptions.RemoveEmptyEntries)
               .ToArray();
            double fuelTwo = double.Parse(dataTruck[1]);
            double consumptionTwo = double.Parse(dataTruck[2]);
            double tankCapacityTwo = double.Parse(dataTruck[3]);
            Vehicle currentTruck = new Truck(fuelTwo, consumptionTwo, tankCapacityTwo);


            string[] dataBus = Console.ReadLine()
               .Split(' ', StringSplitOptions.RemoveEmptyEntries)
               .ToArray();
            double fuelThree = double.Parse(dataBus[1]);
            double consumptionThree = double.Parse(dataBus[2]);
            double tankCapacityThree = double.Parse(dataBus[3]);
            Bus currentBus = new Bus(fuelThree, consumptionThree, tankCapacityThree);

            Engine engine = new Engine(currentCar, currentTruck, currentBus);
            engine.Start();

        }
    }
}
