﻿namespace P01.Vehicles.Models
{
    using System;

    public abstract class Vehicle
    {

        private double tankCapacity;
        private double fuelQuantity;
        private double fuelCapacity;

        public Vehicle(double fuelQuantity, double fuelConsumption, double tankCapacity)
        {
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumption = fuelConsumption;
            this.TankCapacity = tankCapacity;
        }

        public double FuelQuantity { get; set; }
        public double FuelConsumption { get; set; }

        public double TankCapacity 
        {
            get
            {
                return this.tankCapacity;
            }
            set
            {
                if (fuelQuantity > tankCapacity)
                {
                    this.tankCapacity = 0;
                }
                else
                {
                    this.tankCapacity = value;
                }
            }
        }

        public virtual double CoefficientyConsumption { get; } = 1;

        public virtual double CoefficientyRefuel { get; } = 1;

        public virtual void Drive(double distance)
        {
            if (this.FuelQuantity >= distance * (this.FuelConsumption + this.CoefficientyConsumption))
            {
                this.FuelQuantity -= distance * (this.FuelConsumption + this.CoefficientyConsumption);
                Console.WriteLine($"{this.GetType().Name} travelled {distance} km");
            }
            else
            {
                Console.WriteLine($"{this.GetType().Name} needs refueling");
            }
        }

        public virtual void Refuel(double liters)
        {
            if (liters <= 0)
            {
                Console.WriteLine("Fuel must be a positive number");
            }
            else if (this.TankCapacity - this.FuelQuantity < liters)
            {
                Console.WriteLine($"Cannot fit {liters} fuel in the tank");
            }
            else
            {
                this.FuelQuantity += liters * CoefficientyRefuel;
            }
        }

    }
}
