﻿using P01.Vehicles.Models;
using System;
using System.Linq;

namespace P01.Vehicles.Core
{
    public class Engine : IEngine
    {

        public Engine(Vehicle car, Vehicle truck, Bus bus)
        {
            this.Car = car;
            this.Truck = truck;
            this.Bus = bus;
        }

        public Vehicle Car { get; set; }

        public Vehicle Truck { get; set; }

        public Bus Bus { get; set; }


        public void Start()
        {
            
            int number = int.Parse(Console.ReadLine());

            for (int i = 0; i < number; i++)
            {
                string[] command = Console.ReadLine()
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();

                string cmd = command[0];
                string typeVehicle = command[1];
                double thirdNumberOfArray = double.Parse(command[2]);

                if (cmd == "Drive")
                {
                    if (typeVehicle == "Car")
                    {
                        this.Car.Drive(thirdNumberOfArray);
                    }
                    else if (typeVehicle == "Truck")
                    {
                        this.Truck.Drive(thirdNumberOfArray);
                    }
                    else if (typeVehicle == "Bus")
                    {
                        this.Bus.Drive(thirdNumberOfArray);
                    }
                }
                else if (cmd == "Refuel")
                {
                    if (typeVehicle == "Car")
                    {
                        this.Car.Refuel(thirdNumberOfArray);
                    }
                    else if (typeVehicle == "Truck")
                    {
                        this.Truck.Refuel(thirdNumberOfArray);
                    }
                    else if (typeVehicle == "Bus")
                    {
                        this.Bus.Refuel(thirdNumberOfArray);
                    }
                }
                else if (cmd == "DriveEmpty")
                {
                   this.Bus.DriveEmpty(thirdNumberOfArray);
                }
            }

            Console.WriteLine($"Car: {this.Car.FuelQuantity:f2}");
            Console.WriteLine($"Truck: {this.Truck.FuelQuantity:f2}");
            Console.WriteLine($"Bus: {this.Bus.FuelQuantity:f2}");
        }
    }
}
