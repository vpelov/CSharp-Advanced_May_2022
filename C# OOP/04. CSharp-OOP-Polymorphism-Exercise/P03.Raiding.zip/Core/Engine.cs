﻿using P03.Raiding.IO;
using P03.Raiding.Models;
using System.Collections.Generic;
using System.Linq;

namespace P03.Raiding.Core
{
    public class Engine : IEngine
    {
        public Engine()
        {
        }

        public void Start()
        {
            ConsoleReader reader = new ConsoleReader();
            ConsoleWriter writer = new ConsoleWriter();

            List<BaseHero> heroList = new List<BaseHero>();

            int n = int.Parse(reader.Reader());
            for (int i = 0; i < n; i++)
            {
                string heroName = reader.Reader();
                string heroType = reader.Reader();

                switch (heroType)
                {

                    case "Druid":
                        BaseHero druid = new Druid(heroName);
                        heroList.Add(druid);
                        break;
                    case "Paladin":
                        BaseHero paladin = new Paladin(heroName);
                        heroList.Add(paladin);
                        break;                    
                    case "Warrior":
                        BaseHero warrior = new Warrior(heroName);
                        heroList.Add(warrior);
                        break;
                    case "Rogue":
                        BaseHero rogue = new Rogue(heroName);
                        heroList.Add(rogue);
                        break;
                    default:
                        writer.WriteLine("Invalid hero!");
                        break;
                }             

            }
            int kingPower = int.Parse(reader.Reader());

            int totalPower = 0;

            foreach (BaseHero hero in heroList)
            {
                totalPower += hero.Power;
            }

            foreach (BaseHero hero in heroList)
            {
                writer.WriteLine(hero.CastAbility());
            }

            if (totalPower >= kingPower)
            {
                writer.WriteLine("Victory!");
            }
            else
            {
                writer.WriteLine("Defeat...");
            }
        }
    }
}
