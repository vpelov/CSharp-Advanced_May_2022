﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03.Raiding.Core
{
    public interface IEngine
    {
        void Start();
    }
}
