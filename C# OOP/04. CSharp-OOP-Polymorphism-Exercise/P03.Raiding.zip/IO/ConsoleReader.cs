﻿using System;

namespace P03.Raiding.IO
{
    public class ConsoleReader : IReader
    {
        public string Reader()
        {
            string text = Console.ReadLine();
            return text;
        }
    }
}
