﻿
namespace P03.Raiding.IO
{
    public interface IReader
    {
        string Reader();
    }
}
