﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03.Raiding.Models
{
    interface IBaseHero
    {
        
        public string Name { get; set; }

        public int Power { get;}


        string CastAbility();
    }
}
