﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03.Raiding.Models
{
    public class Druid : BaseHero
    {
        public Druid(string name) 
            : base(name)
        {
        }

        public override int Power { get; } = 80;
        
    }
}
