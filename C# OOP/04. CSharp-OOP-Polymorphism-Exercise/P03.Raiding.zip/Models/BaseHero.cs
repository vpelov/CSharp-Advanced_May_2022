﻿using System;

namespace P03.Raiding.Models
{
    public abstract class BaseHero 
    {
        private string name;            // field

        public BaseHero(string name)    //Constructor
        {
            this.Name = name;
        }

        public string Name               //prop Name
        {
            get => this.name;
            set => this.name = value;
        }

        public virtual int Power { get; } = 1;          // prop Power


        public virtual string CastAbility()                         // Metod virtual
        {
            return $"{this.GetType().Name} - {this.Name} healed for {this.Power}";
        }

    }
}
