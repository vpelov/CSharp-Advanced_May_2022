﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04.WildFarm.Core
{
    class Engine : IEngine
    {
        public void Start()
        {
            throw new NotImplementedException();
        }
    }
}
