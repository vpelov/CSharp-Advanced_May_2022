﻿using System;

namespace P04.WildFarm.IO
{
    public class ConsoleReader : IReader
    {
        public string Reader()
        {
            string text = Console.ReadLine();
            return text;
        }
    }
}
