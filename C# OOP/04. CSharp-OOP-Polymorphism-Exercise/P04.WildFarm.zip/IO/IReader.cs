﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04.WildFarm.IO
{
    public interface IReader
    {
        string Reader();
    }
}
