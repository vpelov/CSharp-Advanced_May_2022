﻿namespace P04.WildFarm.Models
{
    public class Meat : Food
    {
        public Meat(int qantity) 
            : base(qantity)
        {
        }
    }
}
