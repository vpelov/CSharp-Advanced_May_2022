﻿namespace P04.WildFarm.Models
{
    public class Vegetable : Food
    {
        public Vegetable(int qantity) 
            : base(qantity)
        {
        }
    }
}
