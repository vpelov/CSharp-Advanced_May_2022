﻿namespace P04.WildFarm.Models
{
    public class Fruit : Food
    {
        public Fruit(int qantity) 
            : base(qantity)
        {
        }
    }
}
