﻿using P04.WildFarm.Core;

namespace P04.WildFarm.Models
{
    public abstract class Food : IFood
    {
        private int quantity;

        public Food(int qantity)
        {
            this.Quantity = quantity;
        }

        public int Quantity { get; set; }
    }
}
