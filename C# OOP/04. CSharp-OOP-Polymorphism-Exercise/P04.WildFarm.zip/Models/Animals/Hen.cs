﻿using P04.WildFarm.IO;
using System.Collections.Generic;

namespace P04.WildFarm.Models.Animals
{
    public class Hen : Bird
    {
        public Hen(string name, double weight, double wingSize) 
            : base(name, weight, wingSize)
        {
        }

        

        ConsoleWriter writer = new ConsoleWriter();

        protected override IReadOnlyCollection<string> Food => new List<string>() { "Vegetable", "Fruit", "Meat", "Seeds" };

        public override void ProducingSound()
        {
            writer.WriteLine("Cluck");
        }

        public override string ToString()
        {
            return $"{this.GetType().Name} [{this.Name}, {this.WingSize}, {this.Weight}, {this.FoodEaten}]";
        }
    }
}
