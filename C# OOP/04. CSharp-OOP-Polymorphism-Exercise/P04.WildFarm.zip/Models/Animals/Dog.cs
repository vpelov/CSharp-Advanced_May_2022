﻿using P04.WildFarm.IO;
using System.Collections.Generic;

namespace P04.WildFarm.Models.Animals
{
    public class Dog : Mammal
    {
        public Dog(string name, double weight, string livingRegion) : base(name, weight, livingRegion)
        {
        }

        protected override IReadOnlyCollection<string> Food => new List<string>() { "Meat" };

        ConsoleWriter writer = new ConsoleWriter();

        public override void ProducingSound()
        {
            writer.WriteLine("Woof");
        }

        public override string ToString()
        {
            return $"{this.GetType().Name} [{this.Name}, {this.Weight}, {this.LivingRegion}, {this.FoodEaten}]";
        }
    }
}
