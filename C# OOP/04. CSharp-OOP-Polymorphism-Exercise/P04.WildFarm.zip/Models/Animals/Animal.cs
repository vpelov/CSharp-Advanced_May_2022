﻿using P04.WildFarm.Models.Interfaces;
using System.Collections.Generic;

namespace P04.WildFarm.Models
{
    public abstract class Animal : IAnimal
    {
        protected Animal(string name, double weight)
        {
            Name = name;
            Weight = weight;
        }

        public string Name { get; set; }

        public double Weight { get; set; }

        public int FoodEaten { get; set; }


        protected abstract IReadOnlyCollection<string> Food { get; }


        public virtual void ProducingSound()
        {

        }

        public virtual string Tostring()
        {
            return "steel not override Tostring()";
        }
        
    }
}
