﻿using P04.WildFarm.IO;
using System.Collections.Generic;

namespace P04.WildFarm.Models.Animals
{
    public class Cat : Feline
    {
        public Cat(string name, double weight, string livingRegion, string breed) 
            : base(name, weight, livingRegion, breed)
        {
        }

        protected override IReadOnlyCollection<string> Food => new List<string>() { "Vegetable", "Meat" };

        ConsoleWriter writer = new ConsoleWriter();

        public override void ProducingSound()
        {
            writer.WriteLine("Meow");
        }

        public override string ToString()
        {
            return $"{this.GetType().Name} [{this.Name}, {this.Breed}, {this.Weight}, {this.LivingRegion}, {this.FoodEaten}]";
        }

    }
}
