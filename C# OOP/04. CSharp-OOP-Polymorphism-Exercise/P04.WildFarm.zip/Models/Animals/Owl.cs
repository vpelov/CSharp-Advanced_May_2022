﻿using P04.WildFarm.IO;
using System;
using System.Collections.Generic;
using System.Text;

namespace P04.WildFarm.Models.Animals
{
    public class Owl : Bird
    {
        public Owl(string name, double weigth, double wingSize) 
            : base(name, weigth, wingSize)
        {
        }

        protected override IReadOnlyCollection<string> Food => new List<string>() { "Meat"};

        ConsoleWriter writer = new ConsoleWriter();

        public override void ProducingSound()
        {
            writer.WriteLine("Hoot Hoot");
        }

        public override string ToString()
        {
            return $"{this.GetType().Name} [{this.Name}, {this.WingSize}, {this.Weight}, {this.FoodEaten}]";
        }
    }
}
