﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04.WildFarm.Core
{
    interface IFood
    {
        public int Quantity { get; set; }
    }
}
