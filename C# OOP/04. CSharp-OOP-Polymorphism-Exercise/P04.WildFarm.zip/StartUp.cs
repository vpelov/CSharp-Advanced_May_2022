﻿using System;

namespace P04.WildFarm
{
    class StartUp
    {
        static void Main(string[] args)
        {



        }
    }
}
