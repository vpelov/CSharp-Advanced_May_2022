﻿using P01.Vehicles.Core;
using P01.Vehicles.Models;
using System;
using System.Linq;

namespace P01.Vehicles
{
    public class StartUp
    {
        static void Main()
        {
            string[] inData = Console.ReadLine()
                .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                .ToArray();
            string car = inData[0];
            double fuel = double.Parse(inData[1]);
            double consumption = double.Parse(inData[2]);
            Vehicle currentCar = new Car(fuel, consumption);

            string[] inDataTwo = Console.ReadLine()
               .Split(' ', StringSplitOptions.RemoveEmptyEntries)
               .ToArray();
            string truck = inData[0];
            double fuelTwo = double.Parse(inDataTwo[1]);
            double consumptionTwo = double.Parse(inDataTwo[2]);
            Vehicle currentTruck = new Truck(fuelTwo, consumptionTwo);

            Engine engine = new Engine(currentCar, currentTruck);
            engine.Start();

        }
    }
}
