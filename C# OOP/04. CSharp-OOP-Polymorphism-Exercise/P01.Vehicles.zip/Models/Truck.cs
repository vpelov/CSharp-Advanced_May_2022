﻿namespace P01.Vehicles.Models
{
    public class Truck : Vehicle
    {
        public Truck(double fuelQuantity, double fuelConsumption) 
            : base(fuelQuantity, fuelConsumption)
        {
        }

        public override double CoefficientyConsumption => 1.6;

        public override double CoefficientyRefuel => 0.95;

    }
}
