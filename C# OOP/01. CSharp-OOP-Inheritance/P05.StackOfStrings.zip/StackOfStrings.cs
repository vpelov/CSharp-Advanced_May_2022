﻿using System;
using System.Collections.Generic;


namespace CustomStack
{
    public class StackOfStrings : Stack<string>
    {

        public bool IsEmpty()
        {
            return this.Count == 0;
        }

        public Stack<string> AddRange(IEnumerable<string> sometime)
        {
            Stack<string> result = new Stack<string>();
            foreach (var item in sometime)
            {
                this.Push(item);
            }
            result = this;
            return result;
        }

    }
}
