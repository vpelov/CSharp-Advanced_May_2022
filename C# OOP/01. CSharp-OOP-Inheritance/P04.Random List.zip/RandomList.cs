﻿using System;
using System.Collections.Generic;

namespace CustomRandomList
{
    public class RandomList : List<string>
    {

        public string RandomString()
        {
            Random random = new Random();
            int num = random.Next(this.Count);
            string result = this[num];
            RemoveAt(num);
            return result;
        }
    }
}
