﻿namespace Operations
{
    public interface IEngine
    {
        void Start();

    }
}
