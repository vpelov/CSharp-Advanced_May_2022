﻿namespace P01.MathOperation.Models
{
    public interface IMathOperation
    {        
        public int Add(int a, int b);       
    }
}
