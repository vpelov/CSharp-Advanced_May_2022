﻿using P01.MathOperation.IO.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace P01.MathOperation.IO
{
    public class ConsoleReadre : IReader
    {
        public string ReadLine()
        {
            string text = Console.ReadLine();
            return text;
        }
    }
}
