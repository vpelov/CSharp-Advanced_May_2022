﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01.MathOperation.IO.Interfaces
{
    public interface IWriter
    {
        void Writeline(string text);

        void Write(string text);

    }
}
