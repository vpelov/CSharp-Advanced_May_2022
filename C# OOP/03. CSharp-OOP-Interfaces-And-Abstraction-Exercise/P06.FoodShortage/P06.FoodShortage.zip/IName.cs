﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04.BorderControl
{
    public interface IName
    {
        public string Name { get; set; }
    }
}
