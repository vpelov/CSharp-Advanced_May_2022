﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04.BorderControl
{
    public interface IBirthdate
    {
        
        public string Birthdate { get; set; }

    }
}
