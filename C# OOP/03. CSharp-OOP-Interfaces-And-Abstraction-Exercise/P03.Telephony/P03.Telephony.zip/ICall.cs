﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03.Telephony
{
    public interface ICall
    {
        string Calling();
    }
}
