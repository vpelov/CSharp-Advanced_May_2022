﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03.Telephony
{
    public interface IBrowse
    {
        string Browsing();
    }
}
