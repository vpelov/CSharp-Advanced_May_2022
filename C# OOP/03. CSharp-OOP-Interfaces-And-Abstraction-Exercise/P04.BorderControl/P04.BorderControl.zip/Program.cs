﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P04.BorderControl
{
    class Program
    {
        static void Main(string[] args)
        {
            List<IId> enterList = new List<IId>();
            IId iid;

            string command = Console.ReadLine();
            while (command != "End")
            {
                string[] cmd = command
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();

                if (cmd.Length == 2)
                {
                    string model = cmd[0];
                    string id = cmd[1];

                    iid = new Robot(model, id);
                    enterList.Add(iid);
                }
                else if (cmd.Length == 3)
                {
                    string name = cmd[0];
                    int age = int.Parse(cmd[1]);
                    string id = cmd[2];

                    iid = new Citizen(name, age, id);
                    enterList.Add(iid);
                }
                command = Console.ReadLine();
            }

            string searchNumber = Console.ReadLine();
            List<string> resultList = new List<string>();

            resultList = enterList.Where(x => x.Id.EndsWith(searchNumber)).Select(x => x.Id).ToList();

            foreach (string num in resultList)
            {
                Console.WriteLine(num);
            }
        }       
    }
}
