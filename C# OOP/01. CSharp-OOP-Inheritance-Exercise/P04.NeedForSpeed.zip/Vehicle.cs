﻿namespace NeedForSpeed
{
    public class Vehicle
    {
        private const double DefaultFuelConsumption = 1.25;
        private int horsePower;
        private double fuel;

        public Vehicle(int horsePower, double fuel)
        {
            this.HorsePower = horsePower;
            this.Fuel = fuel;
        }

        public virtual double FuelConsumption 
        {
            get { return DefaultFuelConsumption; }            
        }

        public double Fuel  
        {
            get { return this.fuel; }
            set { this.fuel = value; }
        }

        public int HorsePower  
        {
            get { return this.horsePower; }
            set { this.horsePower = value; }
        }


        public virtual void Drive(double kilometers)
        {
            this.Fuel -= this.FuelConsumption * kilometers; 
        }

    }
}
